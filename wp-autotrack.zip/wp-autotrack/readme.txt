=== WP Autotrack Google Analytics ===
Contributors: watzak
Tags: autotrack, autotrack.js, autotrackjs, analytics, analytics dashboard, anlytics, api, Audience Overview, autotrack, better google analytics, charts, counter, dashboard, demographics, Easy Analytics, ga, GA code, gogle, google, google analytic, google analytics, google analytics autotrack, google analytics dashboard, Google analytics for wordpress, Google Analytics Manager, google analytics plugin, Google Analytics tracking code, google analytics widget, head, hit, hit counter, hits website, install analytics, interests, javascript, keywords, marketing, pageview counter, pageviews, reports, Simple analytics, stats, stats counter, statscounter, statistic, track, tracker, tracking, tracking code, universal tracking, Visit, visitor tracker, Web Statistics, web stats, website visitors, wordpress analytics, cleanUrlTracker, eventTracker, impressionTracker, mediaQueryTracker, outboundFormTracker, outboundLinkTracker, pageVisibilityTracker, socialWidgetTracker, urlChangeTracker
Donate link: https://www.paypal.me/watzak
Requires at least: 4.6
Tested up to: 4.6
Stable tag: 1.0.0
License: GPLv3 or later

License URI: http://www.gnu.org/licenses/gpl.html

Automatic and enhanced Google Analytics tracking for common user interactions on the web.

== Description ==

Automatic and enhanced Google Analytics tracking for common user interactions on the web.

[Author's site](https://github.com/watzak)


Features of the plugins

*   Enables Google Analytics for your site and enhances tracking for common user interactions on the web.


== Installation ==

1. Upload `wp-autotrack` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto the Settings > WP Autotrack Google Analytics to change settings


== Frequently Asked Questions ==
= Where can I find my Google Analytics tracking code? =

You can create a free "property" on the Google Analytics website. The UA code is the tracking code which is used in this plugin.

For any support issues, please use the official WordPress support forums.


== Screenshots ==

1. An example of the admin dashboard.


== Changelog ==

= 1.0.0 - 3 Semptember 2016 =

- Initial version released for WP Autotrack Google Analytics
